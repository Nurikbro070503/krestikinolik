<?php
require_once "./templates/header.php"; 
 ?> 
 		<article class="col border-line col-game-spacing">
			<article class="subtitle-row">
				<h2>Start new game</h2>
			</article>
			<style>
    button{
        width: 50px;
        height: 50px;
    }
    table{
        position: absolute;
        top: 50%;
        left: 50%;
        margin-top: -45px;
        margin-left: -125px;
    }
	.form-win {
		position: absolute;
		top: 50%;
        left: 50%;
        margin-top: 160px;
        margin-left: -165px;
	}
	button.button1{
		width: 150px;
		position: absolute;
		top: 50%;
        left: 50%;
        margin-top: 200px;
        margin-left: -125px;
	}
	.dates {
		margin-left:  95px;
	}
</style>
<p class="dates">Time: <span class="time">12 sec</span></p>
				<h3 class="relative-pos-game">
					<span class="points"><span class="nameuser">Player: 2</span></span><span class="points"><span class="computer">Computer: 2 </span></span>
				</h3>
<table>
    <?
    for($i=1; $i <=9; $i++){
        if ($i==1) {echo "\t<tr>\n";}
        echo "\t\t".'<td><button id = "id_'.$i.'"onclick = "foo_'.$i.'()"class = "block"></button></td>'."\n";
        if($i % 3 == 0) {if($i == 9){echo"\t</tr>";} else {echo "\t</tr>\n\t<tr>\n";}}
    }
    ?>
 </table>
  
			<div class="button-start">
				<a href="play.php"><button class="button1">Начать новую игру.</button></a>
			</div>
 <div id ="rezult"></div>
 <div id ="arhv"></div>

 <script>
    let rezult,button, count; 
    <?
    for ($i = 1; $i <=9; $i++){
        echo 'function foo_'.$i.'(){
            rezult=document.getElementById("rezult").innerHTML;
            button=document.getElementById("id_'.$i.'").innerHTML;
            if(button == ""){
                if (rezult == "x"){
                    znak = "0";
                }else{
                    znak = "x";
                }
                document.getElementById("rezult").innerHTML = znak;
                document.getElementById("id_'.$i.'").innerHTML = znak;
                count=document.getElementById("arhv").innerHTML += arhv; count = count.length;
            }
            winner();
        }';
    }
    ?>
function winner(){ 
    allBlock =  document.getElementsByClassName("block");console.log(allBlock);
  if(allBlock[0].innerHTML =='x' & allBlock[1].innerHTML =='x' & allBlock[2].innerHTML =='x'){alert('Крестики победили!'); location.reload(); fail;} 
  if(allBlock[3].innerHTML =='x' & allBlock[4].innerHTML =='x' & allBlock[5].innerHTML =='x'){alert('Крестики победили!'); location.reload(); fail;}  
  if(allBlock[6].innerHTML =='x' & allBlock[7].innerHTML =='x' & allBlock[8].innerHTML =='x'){alert('Крестики победили!'); location.reload(); fail;}

  if(allBlock[0].innerHTML =='x' & allBlock[3].innerHTML =='x' & allBlock[6].innerHTML =='x'){alert('Крестики победили!'); location.reload(); fail;} 
  if(allBlock[1].innerHTML =='x' & allBlock[4].innerHTML =='x' & allBlock[7].innerHTML =='x'){alert('Крестики победили!'); location.reload(); fail;}  
  if(allBlock[2].innerHTML =='x' & allBlock[5].innerHTML =='x' & allBlock[8].innerHTML =='x'){alert('Крестики победили!'); location.reload(); fail;}

  if(allBlock[0].innerHTML =='x' & allBlock[4].innerHTML =='x' & allBlock[8].innerHTML =='x'){alert('Крестики победили!'); location.reload(); fail;} 
  if(allBlock[2].innerHTML =='x' & allBlock[4].innerHTML =='x' & allBlock[6].innerHTML =='x'){alert('Крестики победили!'); location.reload(); fail;}  

  if(allBlock[0].innerHTML =='0' & allBlock[1].innerHTML =='0' & allBlock[2].innerHTML =='0'){alert('Нолики победили!'); location.reload(); fail;} 
  if(allBlock[3].innerHTML =='0' & allBlock[4].innerHTML =='0' & allBlock[5].innerHTML =='0'){alert('Нолики победили!'); location.reload(); fail;}  
  if(allBlock[6].innerHTML =='0' & allBlock[7].innerHTML =='0' & allBlock[8].innerHTML =='0'){alert('Нолики победили!'); location.reload(); fail;}

  if(allBlock[0].innerHTML =='0' & allBlock[3].innerHTML =='0' & allBlock[6].innerHTML =='0'){alert('Нолики победили!'); location.reload(); fail;} 
  if(allBlock[1].innerHTML =='0' & allBlock[4].innerHTML =='0' & allBlock[7].innerHTML =='0'){alert('Нолики победили!'); location.reload(); fail;}  
  if(allBlock[2].innerHTML =='0' & allBlock[5].innerHTML =='0' & allBlock[8].innerHTML =='0'){alert('Нолики победили!'); location.reload(); fail;}

  if(allBlock[0].innerHTML =='0' & allBlock[4].innerHTML =='0' & allBlock[8].innerHTML =='0'){alert('Нолики победили!'); location.reload(); fail;} 
  if(allBlock[2].innerHTML =='0' & allBlock[4].innerHTML =='0' & allBlock[6].innerHTML =='0'){alert('Нолики победили!'); location.reload(); fail;}

  if(count == "9") { alert('Ничья!');  location.reload(); fail;} 
  console.log(allBlock);
}

 </script>